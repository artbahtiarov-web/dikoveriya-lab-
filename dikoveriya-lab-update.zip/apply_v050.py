#!/usr/bin/env python3
"""Apply workflow UX and data model v0.6 to the checked-out v0.5 repository.
This is an additive migration; existing production records and signing files remain untouched.
The filename is retained for compatibility with the already-installed GitHub Actions uploader.
"""
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'app/src/main/java/ru/dikoveriya/lab'

def patch(path,changes):
    p=ROOT/path
    original=p.read_text(encoding='utf-8')
    text=original
    for a,b in changes:
        if text.count(a)!=1:
            raise AssertionError(f'{path}: expected exactly one anchor, found {text.count(a)} for {a[:90]!r}')
        text=text.replace(a,b,1)
    p.write_text(text,encoding='utf-8')
    print('Patched',path)

DB='app/src/main/java/ru/dikoveriya/lab/LabDatabase.kt'
# All data changes are additive, with FKs and explicit imports from versions 4/5/6.
patch(DB,[
('SQLiteOpenHelper(context, "dikoveriya_lab.db", null, 6)', 'SQLiteOpenHelper(context, "dikoveriya_lab.db", null, 7)'),
('origin_state TEXT NOT NULL DEFAULT \'Не установлено\', quantity_kind TEXT NOT NULL DEFAULT \'Не уточнено\')',
 'origin_state TEXT NOT NULL DEFAULT \'Не установлено\', quantity_kind TEXT NOT NULL DEFAULT \'Не уточнено\', medium_recipe_id INTEGER REFERENCES recipes(id))'),
('stock_mg_ml REAL NOT NULL DEFAULT 0)")', 'stock_mg_ml REAL NOT NULL DEFAULT 0, sugar_g_l REAL, agar_g_l REAL)")'),
('    private fun createExtra(db: SQLiteDatabase) {\n', '''    private fun createExtra(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS culture_measurements (id INTEGER PRIMARY KEY AUTOINCREMENT, culture_id INTEGER NOT NULL REFERENCES cultures(id), recipe_id INTEGER REFERENCES recipes(id), observed_at INTEGER NOT NULL, explants INTEGER CHECK(explants>=0), shoots INTEGER CHECK(shoots>=0), plants INTEGER CHECK(plants>=0), contaminated INTEGER CHECK(contaminated>=0), notes TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE IF NOT EXISTS culture_recipe_history (id INTEGER PRIMARY KEY AUTOINCREMENT, culture_id INTEGER NOT NULL REFERENCES cultures(id), recipe_id INTEGER NOT NULL REFERENCES recipes(id), applied_at INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_measure_culture ON culture_measurements(culture_id,observed_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_measure_recipe ON culture_measurements(recipe_id,observed_at)")
'''),
('''            db.execSQL("INSERT OR IGNORE INTO culture_links(parent_culture_id,child_culture_id,used_qty,result_qty,event_group) SELECT parent_culture_id,child_culture_id,used_qty,resulting_qty,event_group FROM lineage")
        }

    }
''','''            db.execSQL("INSERT OR IGNORE INTO culture_links(parent_culture_id,child_culture_id,used_qty,result_qty,event_group) SELECT parent_culture_id,child_culture_id,used_qty,resulting_qty,event_group FROM lineage")
        }
        if (oldVersion < 7) {
            db.execSQL("ALTER TABLE cultures ADD COLUMN medium_recipe_id INTEGER REFERENCES recipes(id)")
            db.execSQL("ALTER TABLE recipe_parts ADD COLUMN sugar_g_l REAL")
            db.execSQL("ALTER TABLE recipe_parts ADD COLUMN agar_g_l REAL")
            createExtra(db)
            db.execSQL("UPDATE cultures SET medium_recipe_id=(SELECT recipe_id FROM batches WHERE batches.id=cultures.medium_batch_id) WHERE medium_batch_id IS NOT NULL AND medium_recipe_id IS NULL")
            db.execSQL("INSERT INTO culture_recipe_history(culture_id,recipe_id,applied_at,note) SELECT id,medium_recipe_id,created_at,'Перенесено из существующего учёта партий' FROM cultures WHERE medium_recipe_id IS NOT NULL")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_culture_direct_recipe ON cultures(medium_recipe_id)")
        }
    }
'''),
('''    fun addCulture(plantId: Long, quantity: Int, motherId: Long?, batchId: Long?, location: String, notes: String, quantityKind: String = "Не уточнено") {
        writableDatabase.tx { createCultureInDb(this,plantId,quantity,LabTerms.IN_CULTURE,0,LabTerms.IN_VITRO,location,batchId,motherId,notes,quantityKind=quantityKind) }
    }
''','''    fun addCulture(plantId: Long, quantity: Int, motherId: Long?, batchId: Long?, location: String, notes: String, quantityKind: String = "Не уточнено") {
        writableDatabase.tx { createCultureInDb(this,plantId,quantity,LabTerms.IN_CULTURE,0,LabTerms.IN_VITRO,location,batchId,motherId,notes,quantityKind=quantityKind) }
    }
    /** Simple intake: one container, optional mother and recipe; all three measurements are independent. */
    fun addCultureQuick(plantId:Long,motherId:Long?,recipeId:Long?,explants:Int?,shoots:Int?,plantsCount:Int?,location:String,notes:String):Long {
        val counts=listOf(explants,shoots,plantsCount)
        require(counts.all{it==null || it in 0..1000000}) { "Проверь числа объектов" }
        require(counts.any{it!=null && it>0}) { "Укажи хотя бы один положительный показатель" }
        val quantity=when { (plantsCount?:0)>0->plantsCount!!; (shoots?:0)>0->shoots!!; else->explants!! }
        val kind=when { (plantsCount?:0)>0->"Растения"; (shoots?:0)>0->"Побеги"; else->"Экспланты" }
        var resultId=0L
        writableDatabase.tx {
            if(recipeId!=null) {
                val r=recipes().firstOrNull{it.id==recipeId}?:error("Рецептура не найдена")
                require(r.status=="Утверждена") { "Выбирай только готовые рецептуры" }
                require(r.plantId==null || r.plantId==plantId) { "Эта рецептура предназначена для другого растения" }
            }
            val id=createCultureInDb(this,plantId,quantity,LabTerms.IN_CULTURE,0,LabTerms.IN_VITRO,location,null,motherId,notes,quantityKind=kind)
            update("cultures",cv("medium_recipe_id" to recipeId),"id=?",arrayOf(id.toString()))
            if(recipeId!=null) {
                insertOrThrow("culture_recipe_history",null,cv("culture_id" to id,"recipe_id" to recipeId,"applied_at" to System.currentTimeMillis(),"note" to "Выбрана при создании"))
                event(this,id,"Назначение среды","Рецептура ${recipes().first{it.id==recipeId}.name} · версия ${recipes().first{it.id==recipeId}.version}",quantity,quantity,null)
            }
            insertOrThrow("culture_measurements",null,cv("culture_id" to id,"recipe_id" to recipeId,"observed_at" to System.currentTimeMillis(),"explants" to explants,"shoots" to shoots,"plants" to plantsCount,"notes" to "Показатели при создании"))
            resultId=id
        }
        return resultId
    }
'''),
('c.origin_state,c.quantity_kind FROM cultures c', 'c.origin_state,c.quantity_kind,c.medium_recipe_id FROM cultures c'),
('c.getString(12),c.getString(13),c.getString(14)))', 'c.getString(12),c.getString(13),c.getString(14),c.optLong(15)))'),
('        val BACKUP_ORDER=BACKUP_ORDER_V5+listOf("ingredient_catalog")', '        val BACKUP_ORDER_V6=BACKUP_ORDER_V5+listOf("ingredient_catalog")\n        val BACKUP_ORDER=BACKUP_ORDER_V6+listOf("culture_measurements","culture_recipe_history")'),
('put("schema",6)', 'put("schema",7)'),
('root.optInt("schema") in 4..6', 'root.optInt("schema") in 4..7'),
('val importOrder=when(fromVersion){4->BACKUP_ORDER_V4;5->BACKUP_ORDER_V5;else->BACKUP_ORDER}', 'val importOrder=when(fromVersion){4->BACKUP_ORDER_V4;5->BACKUP_ORDER_V5;6->BACKUP_ORDER_V6;else->BACKUP_ORDER}'),
('''            if(fromVersion<6) {
                // Imported older backups have no ingredient catalog. Restore safe names without doses.
                createExtra(this)
            }
''','''            if(fromVersion<6) {
                // Imported older backups have no ingredient catalog. Restore safe names without doses.
                createExtra(this)
            }
            if(fromVersion<7) {
                execSQL("UPDATE cultures SET medium_recipe_id=(SELECT recipe_id FROM batches WHERE batches.id=cultures.medium_batch_id) WHERE medium_batch_id IS NOT NULL AND medium_recipe_id IS NULL")
                execSQL("INSERT INTO culture_recipe_history(culture_id,recipe_id,applied_at,note) SELECT id,medium_recipe_id,created_at,'Перенесено из резервной копии' FROM cultures WHERE medium_recipe_id IS NOT NULL")
            }
''')
])

patch('app/src/main/java/ru/dikoveriya/lab/LabModels.kt',[
('val quantityKind: String = "Не уточнено"\n)', 'val quantityKind: String = "Не уточнено", val recipeId: Long? = null\n)')
])
patch('app/src/main/java/ru/dikoveriya/lab/LabBackup.kt',[
('root.getInt("schema") in 4..6','root.getInt("schema") in 4..7')
])
patch('app/build.gradle.kts',[
('versionCode = 50000 +','versionCode = 60000 +'),
('versionName = "0.5.0-dev"','versionName = "0.6.0-dev"')
])

MAIN='app/src/main/java/ru/dikoveriya/lab/MainActivity.kt'
patch(MAIN,[
('    var recipeId by remember { mutableStateOf<Long?>(null) }','''    var recipeId by remember { mutableStateOf<Long?>(null) }
    var advancedRecipeId by remember { mutableStateOf<Long?>(null) }
    var preselectedRecipeId by remember { mutableStateOf<Long?>(null) }
    var performanceCultureId by remember { mutableStateOf<Long?>(null) }'''),
('    val metrics=remember(refresh){db.recipeMetrics()}','''    val metrics=remember(refresh){db.recipeMetrics()}
    val cultivarResults=remember(refresh){db.plantResults()}
    val mediumResults=remember(refresh){db.mediumResults()}'''),
('MaterialTheme(colorScheme=lightColorScheme(\n        primary=Color(0xFF455E50), onPrimary=Color.White,\n        background=Color(0xFFF5F6F2), surface=Color(0xFFFCFDF9),\n        surfaceVariant=Color(0xFFE6EAE2), onSurface=Color(0xFF24322A)\n    ))', 'DikoveriyaTheme'),
('Scaffold(bottomBar={', 'Scaffold(containerColor=MaterialTheme.colorScheme.background,bottomBar={'),
('            NavigationBar {', '            NavigationBar(containerColor=MaterialTheme.colorScheme.surface,tonalElevation=2.dp) {'),
('''"newCulture" -> AddCultureDialog(plants,mothers,batches,onClose={dialog=""},onSave={p,q,m,b,place,note,kind->if(act{db.addCulture(p,q,m,b,place,note,kind)})dialog=""})''','''"newCulture" -> QuickCultureDialog(db,preselectedRecipeId,onClose={dialog="";preselectedRecipeId=null},
                    onSaved={id->dialog="";preselectedRecipeId=null;refresh++;cultureId=id},onChanged={refresh++})'''),
('''"newRecipe" -> AddRecipeDialog(plants,onClose={dialog=""},onSave={name,purpose,p,note->if(act{db.createRecipe(name,purpose,p,note)})dialog=""})''','''"newRecipe" -> QuickMediumDialog(db,onClose={dialog=""},onSaved={id->dialog="";refresh++;recipeId=id},
                    onUseExisting={id->dialog="";recipeId=id})'''),
('''                    onObserve={n,start,healthy,infected,days->if(act{db.addObservation(id,n,start,healthy,infected,days)})cultureId=null},
                    onOperations={actionCultureId=id;cultureId=null},''','''                    onObserve={n,start,healthy,infected,days->if(act{db.addObservation(id,n,start,healthy,infected,days)})cultureId=null},
                    onGrowth={performanceCultureId=id;cultureId=null},
                    onOperations={actionCultureId=id;cultureId=null},'''),
('''            recipeId?.let{id->recipes.firstOrNull{it.id==id}?.let{r->
                RecipeDialog(r,db.recipeParts(id),ingredients,onClose={recipeId=null},''','''            recipeId?.let{id->recipes.firstOrNull{it.id==id}?.let{r->
                EasyRecipeDialog(db,r,plants.firstOrNull{it.id==r.plantId}?.name,onClose={recipeId=null},
                    onUse={target->recipeId=null;preselectedRecipeId=target;dialog="newCulture"},
                    onAdvanced={advancedRecipeId=id;recipeId=null})
            }}
            advancedRecipeId?.let{id->recipes.firstOrNull{it.id==id}?.let{r->
                RecipeDialog(r,db.recipeParts(id),ingredients,onClose={advancedRecipeId=null},'''),
('''onRevise={if(act{db.reviseRecipe(id)})recipeId=null},
                    onPrepare={volume,ph,sterilization,note,actual->if(act{db.prepareBatch(id,volume,ph,sterilization,note,actual)})recipeId=null}''','''onRevise={if(act{db.reviseRecipe(id)})advancedRecipeId=null},
                    onPrepare={volume,ph,sterilization,note,actual->if(act{db.prepareBatch(id,volume,ph,sterilization,note,actual)})advancedRecipeId=null}'''),
('''            batchId?.let{id->''','''            performanceCultureId?.let{id->cultures.firstOrNull{it.id==id}?.let{c->
                GrowthDialog(db,c,onClose={performanceCultureId=null},onChanged={refresh++})
            }}
            batchId?.let{id->'''),
('''item { SectionTitle("Эффективность питательных сред") }''','''item { SectionTitle("Результаты по сортам") }
                        items(cultivarResults,key={"results-${it.plantId}"}) { r ->
                            SmallCard(r.name,"Контейнеров: ${r.containers} · эксплантов: ${r.lastExplants} · побегов: ${r.lastShoots} · растений: ${r.lastPlants} · выручка: ${money(r.revenue)}") {}
                        }
                        item { SectionTitle("Рост по рецептурам") }
                        item { Text("Последнее наблюдение каждого контейнера на данной рецептуре; разные контейнеры могут иметь разные исходные условия.",style=MaterialTheme.typography.bodySmall) }
                        items(mediumResults,key={"medium-stats-${it.recipeId}"}) { r ->
                            SmallCard(r.name,"Контейнеров: ${r.cultures} · наблюдений для сравнения: ${r.observations} · побегов: ${r.latestShoots} · растений: ${r.latestPlants}") {}
                        }
                        item { SectionTitle("Эффективность питательных сред (прежний журнал)") }'''),
('''if(metrics.isEmpty()) item { Text("Пока нет измерений, связанных с партиями сред. Открой контейнер → Осмотр → Записать показатели.") }''','''if(metrics.isEmpty()) item { Text("Нет измерений из прежнего журнала партий. Новый журнал находится в карточке контейнера → Рост и результаты.") }'''),
('''Button(onClick={dialog="newRecipe"}){Text("+ Рецептура")}''','''Button(onClick={dialog="newRecipe"}){Text("+ Новая среда")}'''),
('''OutlinedButton(onClick={dialog="batchChooser"}){Text("Приготовить")}''','''OutlinedButton(onClick={dialog="batchChooser"}){Text("Учесть партию (необязательно)")}'''),
('''item { SectionTitle("Рецептуры") }''','''item { SectionTitle("Готовые питательные среды") }''')
])
# Expose the observations where users work, instead of asking them to visit analytics.
patch('app/src/main/java/ru/dikoveriya/lab/LabForms.kt',[
('''    onObserve:(String,Int?,Int?,Int?,Int?)->Unit,
    onOperations:()->Unit''','''    onObserve:(String,Int?,Int?,Int?,Int?)->Unit,
    onGrowth:()->Unit,
    onOperations:()->Unit'''),
('''listOf("История","Что произошло?","Осмотр","Изменить","Продажа","Фото","Этикетка")''','''listOf("История","Рост и результаты","Что произошло?","Осмотр","Изменить","Продажа","Фото","Этикетка")'''),
('''            when(mode){
                "Что произошло?" -> {''','''            when(mode){
                "Рост и результаты" -> {
                    Text("Отдельные счётчики эксплантов, побегов, растений и заражений; дата и рецептура каждого измерения сохраняются.",style=MaterialTheme.typography.bodySmall)
                    Button(onClick=onGrowth,modifier=Modifier.fillMaxWidth()){Text("Открыть журнал роста")}
                }
                "Что произошло?" -> {'''),
('''            Text("${c.status} · ${c.stage} · ${c.quantity} · ${c.quantityKind}")''','''            Text("${c.status} · ${c.stage} · учётное количество ${c.quantity} (${c.quantityKind})")'''),
('''Text("Партия среды: ${batches.firstOrNull{it.id==c.batchId}?.code?:"не указана"}",style=MaterialTheme.typography.bodySmall)''','''Text("Партия приготовления (если велась): ${batches.firstOrNull{it.id==c.batchId}?.code?:"не указана"}",style=MaterialTheme.typography.bodySmall)''')
])

# Theme must be used by ALL tabs and every form, not only a promotional mock-up.
patch('app/src/main/java/ru/dikoveriya/lab/UiBasics.kt',[
('import androidx.compose.foundation.clickable','import androidx.compose.foundation.BorderStroke\nimport androidx.compose.foundation.clickable'),
('import androidx.compose.ui.text.font.FontWeight','import androidx.compose.ui.text.font.FontWeight\nimport androidx.compose.ui.graphics.Color'),
('''@Composable fun SectionTitle(s: String) { Text(s,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold) }''','''@Composable fun SectionTitle(s: String) {
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Surface(Modifier.size(width=3.dp,height=21.dp),shape=RoundedCornerShape(4.dp),color=MaterialTheme.colorScheme.tertiary){}
        Text(s,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.SemiBold)
    }
}'''),
('''modifier=Modifier.fillMaxWidth())
}
@Composable fun PickOne''','''modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp))
}
@Composable fun PickOne'''),
('''    ElevatedCard(onClick=onClick,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {''','''    OutlinedCard(onClick=onClick,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),
        colors=CardDefaults.outlinedCardColors(containerColor=MaterialTheme.colorScheme.surface),
        border=BorderStroke(1.dp,MaterialTheme.colorScheme.outlineVariant)) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {''')
])

# Avoid catalogue duplicates differing only by case/whitespace.
patch('app/src/main/java/ru/dikoveriya/lab/LabDatabase.kt',[
('''    fun addPlant(name: String, notes: String = "") {
        writableDatabase.insertOrThrow("plants", null, cv("name" to checkText(name,120), "description" to notes.take(1000)))
    }''','''    fun addPlant(name: String, notes: String = "") {
        val clean=checkText(name,120)
        val exists=readableDatabase.rawQuery("SELECT 1 FROM plants WHERE lower(trim(name))=lower(?) LIMIT 1",arrayOf(clean)).use { it.moveToFirst() }
        require(!exists) { "Это растение уже есть в каталоге. Выбери его из списка" }
        writableDatabase.insertOrThrow("plants", null, cv("name" to clean, "description" to notes.take(1000)))
    }''')
])

# Matching header and dashboard metrics; same design system as all other screens.
patch('app/src/main/java/ru/dikoveriya/lab/MainActivity.kt',[
('import androidx.compose.ui.graphics.Color', 'import androidx.compose.ui.graphics.Color\nimport androidx.compose.ui.res.painterResource'),
('''                    Row(verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)) {''','''                    Row(verticalAlignment=Alignment.CenterVertically){
                        Icon(painterResource(R.drawable.ic_dikoveriya_logo),contentDescription=null,
                            tint=Color.Unspecified,modifier=Modifier.size(40.dp))
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {'''),
('''    ElevatedCard(modifier=modifier){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){''','''    Card(modifier=modifier,shape=androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){''')
])
# QA for patch itself is shipped inside zip; do not rely on optimistic UI previews.
print('0.6 update patch applied; run qa/check_v050.py and Gradle build')
