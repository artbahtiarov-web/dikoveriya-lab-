#!/usr/bin/env python3
"""Apply 0.5 changes to the checked-out v0.4 app without replacing other modules.
All edits are guarded and fail closed if source patterns change.
"""
from pathlib import Path
import re
ROOT = Path(__file__).parent
SRC = ROOT/'app/src/main/java/ru/dikoveriya/lab'

def update(path, changes):
    content = path.read_text(encoding='utf-8')
    original = content
    for old, new in changes:
        if old not in content:
            if new in content:
                continue
            raise RuntimeError(f'Неизвестная версия исходного файла {path}; отсутствует {old[:100]!r}')
        if content.count(old) != 1:
            raise RuntimeError(f'Неоднозначное изменение {path}: {old[:100]!r}')
        content = content.replace(old, new, 1)
    if content != original:
        path.write_text(content, encoding='utf-8')
        print('Updated', path.relative_to(ROOT))

DB = SRC/'LabDatabase.kt'
initial_ingredients = [
    ('Babio MS (готовая смесь)', 'Базовая среда', 'г/л', 'Проверь этикетку конкретной партии: комплексная смесь может уже содержать сахарозу и агар.'),
    ('Сахароза', 'Углеводы', 'г/л', 'Если уже входит в готовую смесь, не добавляй повторно.'),
    ('Агар', 'Загуститель', 'г/л', 'Если уже входит в готовую смесь, не добавляй повторно.'),
    ('6-БАП (6-бензиламинопурин)', 'Регулятор роста', 'мг/л', 'Цитокинин; дозировку выбирай по протоколу.'),
    ('NAA (НУК)', 'Регулятор роста', 'мг/л', 'Ауксин; дозировку выбирай по протоколу.'),
    ('IBA (ИМК)', 'Регулятор роста', 'мг/л', 'Ауксин; дозировку выбирай по протоколу.'),
    ('Активированный уголь', 'Добавка', 'г/л', 'Может связывать регуляторы роста и другие вещества.'),
    ('Мио-инозитол', 'Витамины', 'мг/л', ''),
    ('Тиамин (B1)', 'Витамины', 'мг/л', ''),
    ('Железо-ЭДТА', 'Минералы', 'мг/л', 'Учитывай соли железа уже входящие в базовую среду.'),
    ('Кокосовая вода', 'Добавка', 'мл/л', 'Состав натурального материала изменчив.'),
]
from json import dumps
# Use parameterized insert? In onCreate/createExtra SQL values known and escaped safely.
seed_lines = '\n'.join('        db.execSQL("INSERT OR IGNORE INTO ingredient_catalog(name,category,unit,notes) VALUES (?,?,?,?)", arrayOf('+','.join('"'+v.replace('\\','\\\\').replace('"','\\"')+'"' for v in item)+'))' for item in initial_ingredients)
create_snippet = '''        db.execSQL("CREATE TABLE IF NOT EXISTS ingredient_catalog (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, category TEXT NOT NULL, unit TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', archived INTEGER NOT NULL DEFAULT 0)")
''' + seed_lines + '\n'
update(DB, [
 ('SQLiteOpenHelper(context, "dikoveriya_lab.db", null, 5)', 'SQLiteOpenHelper(context, "dikoveriya_lab.db", null, 6)'),
 ('    private fun createExtra(db: SQLiteDatabase) {\n', '    private fun createExtra(db: SQLiteDatabase) {\n'+create_snippet),
 ('    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {', '    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {\n        if (oldVersion < 6) createExtra(db)'),
 ('        val BACKUP_ORDER=BACKUP_ORDER_V4+listOf(', '        val BACKUP_ORDER_V5=BACKUP_ORDER_V4+listOf('),
 ('        val BACKUP_ORDER_V5=BACKUP_ORDER_V4+listOf("lab_operations","operation_changes","culture_links","incident_links","incident_followups","operation_losses")', '        val BACKUP_ORDER_V5=BACKUP_ORDER_V4+listOf("lab_operations","operation_changes","culture_links","incident_links","incident_followups","operation_losses")\n        val BACKUP_ORDER=BACKUP_ORDER_V5+listOf("ingredient_catalog")'),
 ('put("schema",5)', 'put("schema",6)'),
 ('root.optInt("schema") in 4..5', 'root.optInt("schema") in 4..6'),
 ('val importOrder=if(fromVersion==4) BACKUP_ORDER_V4 else BACKUP_ORDER', 'val importOrder=when(fromVersion){4->BACKUP_ORDER_V4;5->BACKUP_ORDER_V5;else->BACKUP_ORDER}'),
 ('            if(fromVersion==4) {', '            if(fromVersion<6) {\n                // Imported older backups have no ingredient catalog. Restore safe names without doses.\n                createExtra(this)\n            }\n            if(fromVersion==4) {'),
])

backup=SRC/'LabBackup.kt'
update(backup,[('root.getInt("schema") in 4..5','root.getInt("schema") in 4..6')])

main=SRC/'MainActivity.kt'
update(main,[
 ('import android.os.Bundle','import android.os.Bundle\nimport android.os.SystemClock\nimport android.widget.Toast\nimport androidx.activity.compose.BackHandler'),
 ('    var tab by remember { mutableStateOf("Главная") }', '    var tab by remember { mutableStateOf("Главная") }\n    val tabHistory=remember{mutableStateListOf<String>()}'),
 ('    var statusFilter by remember { mutableStateOf("Все") }','''    var statusFilter by remember { mutableStateOf("Все") }
    var showIngredients by remember { mutableStateOf(false) }
    var plantRecipeFilter by remember { mutableStateOf("Все растения") }
    var purposeRecipeFilter by remember { mutableStateOf("Любое назначение") }
    var lastExitRequest by remember { mutableLongStateOf(0L) }'''),
 ('    val recipes=remember(refresh){db.recipes()}','    val recipes=remember(refresh){db.recipes()}\n    val ingredients=remember(refresh){db.ingredients()}'),
 ('    val openSection: (String)->Unit = {tab="Ещё";subsection=it}', '    val openSection: (String)->Unit = {if(tab!="Ещё")tabHistory.add(tab);tab="Ещё";subsection=it}'),
 ('    val openCulture: (Long)->Unit = {cultureId=it}', '''    val openCulture: (Long)->Unit = {cultureId=it}
    // Android system Back gesture from either edge uses this handler. Dialogs own their Back events.
    BackHandler(enabled=dialog.isEmpty() && cultureId==null && actionCultureId==null &&
        recipeId==null && batchId==null && materialId==null && experimentId==null && restoreUri==null && error==null) {
        when {
            subsection.isNotEmpty() -> subsection=""
            tabHistory.isNotEmpty() -> { tab=tabHistory.removeAt(tabHistory.lastIndex); subsection="" }
            tab!="Главная" -> { tab="Главная"; subsection="" }
            else -> {
                val now=SystemClock.elapsedRealtime()
                if(now-lastExitRequest<2200L) (context as? android.app.Activity)?.finish()
                else { lastExitRequest=now; Toast.makeText(context,"Повтори жест «Назад» для выхода",Toast.LENGTH_SHORT).show() }
            }
        }
    }'''),
 ('NavigationBarItem(selected=tab==name,onClick={tab=name;subsection=""}', 'NavigationBarItem(selected=tab==name,onClick={if(name=="Главная")tabHistory.clear() else if(tab!=name)tabHistory.add(tab);tab=name;subsection=""}'),
 ('MaterialTheme(colorScheme=lightColorScheme(primary=Color(0xFF255B47)))', '''MaterialTheme(colorScheme=lightColorScheme(
        primary=Color(0xFF455E50), onPrimary=Color.White,
        background=Color(0xFFF5F6F2), surface=Color(0xFFFCFDF9),
        surfaceVariant=Color(0xFFE6EAE2), onSurface=Color(0xFF24322A)
    ))'''),
 ('                                        Button(onClick={dialog="newRecipe"}){Text("+ Рецептура")}', '                                        Button(onClick={dialog="newRecipe"}){Text("+ Рецептура")}'),
 ('                                    item { SectionTitle("Рецептуры") }', '''                                    item { OutlinedButton(onClick={showIngredients=!showIngredients}) { Text(if(showIngredients) "Скрыть компоненты" else "Компоненты среды · ${ingredients.size}") } }
                                    if(showIngredients) item { OutlinedButton(onClick={dialog="newIngredient"}) { Text("+ Добавить компонент") } }
                                    if(showIngredients && ingredients.isEmpty()) item { Text("Компонентов пока нет") }
                                    if(showIngredients) items(ingredients,key={"ingredient-${it.id}"}) { ing ->
                                        SmallCard(ing.name,"${ing.category} · ${ing.unit}") { dialog="ingredientInfo:${ing.id}" }
                                    }
                                    item { SectionTitle("Рецептуры") }
                                    item { PickOne("Растение",listOf("Все растения")+plants.map{it.name},plantRecipeFilter,{plantRecipeFilter=it}) }
                                    item { PickOne("Назначение",listOf("Любое назначение")+LabTerms.purposes,purposeRecipeFilter,{purposeRecipeFilter=it}) }'''),
 ('                                    items(recipes,key={"recipe-${it.id}"}){r->SmallCard(r.name,"${r.purpose} · версия ${r.version} · ${r.status}"){recipeId=r.id}}', '''                                    items(recipes.filter { r ->
                                        (plantRecipeFilter=="Все растения" || r.plantId==null || plants.firstOrNull{it.id==r.plantId}?.name==plantRecipeFilter) &&
                                        (purposeRecipeFilter=="Любое назначение" || r.purpose==purposeRecipeFilter)
                                    },key={"recipe-${it.id}"}) { r ->
                                        val plantName=plants.firstOrNull{it.id==r.plantId}?.name?:"Для любых растений"
                                        SmallCard(r.name,"$plantName · ${r.purpose} · версия ${r.version} · ${r.status}"){recipeId=r.id}
                                    }'''),
 ('                "newRecipe" -> AddRecipeDialog(plants,onClose={dialog=""}', '''                "newIngredient" -> AddIngredientDialog(onClose={dialog=""},onSave={name,category,unit,notes->
                    if(act{db.addIngredient(name,category,unit,notes)})dialog=""
                })
                "newRecipe" -> AddRecipeDialog(plants,onClose={dialog=""}'''),
 ('            if(dialog.startsWith("plantInfo:")){', '''            if(dialog.startsWith("ingredientInfo:")){
                val ing=ingredients.firstOrNull{it.id.toString()==dialog.substringAfter(':')}
                if(ing!=null) DialogForm(ing.name,close={dialog=""}){
                    Text("Категория: ${ing.category} · ${ing.unit}")
                    Text(ing.notes.ifBlank{"Дополнительные сведения не указаны"})
                }
            }
            if(dialog.startsWith("plantInfo:")){'''),
 ('RecipeDialog(r,db.recipeParts(id),onClose={recipeId=null}' , 'RecipeDialog(r,db.recipeParts(id),ingredients,onClose={recipeId=null}'),
])

forms=SRC/'LabForms.kt'
update(forms,[
 ('    r:RecipeRecord,parts:List<RecipePart>,onClose:()->Unit,', '    r:RecipeRecord,parts:List<RecipePart>,catalog:List<IngredientEntry>,onClose:()->Unit,'),
 ('                    Field("Компонент",partName,{partName=it})', '''                    if(catalog.isNotEmpty()) PickOne("Из справочника",listOf("Ввести вручную")+catalog.map{it.name},
                        catalog.firstOrNull{it.name==partName}?.name?:"Ввести вручную",{ name ->
                            if(name!="Ввести вручную") {
                                val choice=catalog.first{it.name==name}
                                partName=choice.name
                                partUnit=choice.unit
                            } else partName=""
                        },"Справочник подставляет название и единицу. Дозировку для каждой рецептуры задаёшь отдельно по проверенному источнику.")
                    Field("Компонент",partName,{partName=it})'''),
])

manifest=ROOT/'app/src/main/AndroidManifest.xml'
update(manifest,[('android:label="Диковерия LAB"','android:label="Диковерия LAB"\n        android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher"')])

gradle=ROOT/'app/build.gradle.kts'
update(gradle,[('versionCode = 40000 +','versionCode = 50000 +'),('versionName = "0.4.0-dev"','versionName = "0.5.0-dev"')])
print('PATCH OK')
